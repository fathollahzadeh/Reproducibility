#ifndef RAPIDJSONCPP_TYPES_H
#define RAPIDJSONCPP_TYPES_H
#include <string>

using namespace std;
enum ValueType {
    FP32, FP64, INT32, INT64, BOOLEAN, STRING
};

#endif //RAPIDJSONCPP_TYPES_H
