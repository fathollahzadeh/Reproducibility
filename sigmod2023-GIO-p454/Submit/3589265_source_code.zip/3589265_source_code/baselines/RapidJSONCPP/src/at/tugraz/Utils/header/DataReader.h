#ifndef RAPIDJSONCPP_DATAREADER_H
#define RAPIDJSONCPP_DATAREADER_H

#include <iostream>
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"

using namespace rapidjson;
using namespace std;

class DataReader {

public:

//    Document getValue(Document d,const char * key);
//
//    int getIntValue(const char * key);
//
//    long getLongValue(const char * key);
//
//    float getFloatValue(const char * key);
//
//    double getDoubleValue(const char * key);
//
//    string getStringValue(const char * key);
//
//    bool getBoolValue(const char * key);

};


#endif //RAPIDJSONCPP_DATAREADER_H
