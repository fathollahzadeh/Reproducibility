#include "DataReader.h"

//
//int DataReader::getIntValue(const char * key) {
//    if (document.HasMember(key) && !document[key].IsNull())
//        return document[key].GetInt();
//    else
//        return 0;
//}
//
//Value** DataReader::getValue(Document  d, const char *key) {
//
//    if (d.HasMember(key) && !d[key].IsNull())
//        return d[key];
//}
//
//long DataReader::getLongValue(const char * key) {
//    return 0;
//}
//
//float DataReader::getFloatValue(const char * key) {
//    return 0;
//}
//
//double DataReader::getDoubleValue(const char * key) {
//    return 0;
//}
//
//string DataReader::getStringValue(const char * key) {
//    return std::string();
//}
//
//bool DataReader::getBoolValue(const char * key) {
//    return false;
//}