
#ifndef RAPIDJSONCPP_ITEMOBJECT_H
#define RAPIDJSONCPP_ITEMOBJECT_H

class ItemObject {

public:
    ItemObject() {}

    virtual ~ItemObject() { }

    virtual void print() {  }

};

#endif //RAPIDJSONCPP_ITEMOBJECT_H
