## Temporal Data Path
This subdirectory contains raw data. We will move the refined data to the 'data' directory at the root folder.

We need to download the 'yelp_dataset.tar' dataset manually and store it here. After extracting it, we will have the following data:
* yelp_academic_dataset_review.json
* yelp_academic_dataset_business.json 
* yelp_academic_dataset_tip.json
* yelp_academic_dataset_checkin.json   
* yelp_academic_dataset_user.json 